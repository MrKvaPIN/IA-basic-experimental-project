import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

# 引入数据集
digits = load_digits()
data = digits.data
# 打印各项参数
print(data[1])
print(digits.images[1])
print(digits.target[1])
plt.imshow(digits.images[1])
plt.show()
print(data.shape)

# 分离数据集
# 划分训练集和测试集，其中测试集占总数据的25%，随机种子设为33
# train_x 和 train_y 是训练集的特征数据和目标数据
train_x, test_x, train_y, test_y = train_test_split(data,digits.target,test_size=0.25,random_state=33)

# 指定分类器(k值)
knn = KNeighborsClassifier(n_neighbors=5)
# 使用训练集训练分类器
knn.fit(train_x,train_y)

# 输出预测结果
print('KNN测试集得分:%.4lf'%knn.score(test_x,test_y))
print('KNN训练集得分:%.4lf'%knn.score(train_x,train_y))